---
name: 甄云项目周报生成助手
version: 1.0.0
description: "Generate polished SRM project weekly report HTML pages and PNG images for 甄云科技 SRM delivery projects. Specialized for project portfolio reports with PM cards, project phase distribution charts, risk level indicators, payment collection progress, active project statistics, and milestone tracking. Use when the user asks for 项目周报, 甄云周报, SRM周报, 项目进展报告, PM周报, or wants to generate a project portfolio weekly report from meeting notes, project status data, or task updates."
---

# 甄云项目周报生成助手

为甄云科技 SRM 交付项目生成专业的项目组合周报。核心流程分为两阶段：

1. 将原始素材（会议纪要、项目状态数据、任务更新等）结构化整理为周报内容模型。
2. 应用 UI Ux Pro Max 设计方法，生成精炼的 HTML 周报页面并导出 PNG 图片。

此 Skill 专门针对甄云 SRM 项目组合周报场景优化，默认包含 PM 卡片、项目阶段分布、风险等级标识、回款进度等核心模块。

## 适用场景

- 甄云 SRM 项目组合周报
- 多项目状态汇总报告
- PM 团队工作进展汇报
- 面向管理层的项目概览

不适用于通用 UI 设计、独立应用仪表盘等非周报类任务。

## 默认输出

生成一个 `.html` 文件和一个匹配的 `.png` 预览图片。

- CSS 写在 `<style>` 块内，自包含无外部依赖。
- 优先使用语义化 HTML：`header`、`main`、`section`、`table`、`figure`。
- 页面响应式且可打印。
- 默认中文输出。
- 视觉风格专业、适合商业汇报。
- 始终同时输出 HTML 和 PNG，除非用户明确只需要 HTML。

## 核心周报模块

甄云项目周报默认包含以下模块（根据原始素材自动裁剪缺失模块）：

1. **报告头部**：标题、报告周期、团队/部门、负责人。
2. **核心指标概览**：活跃项目数、PM 人数、高风险项目数、回款进度等 KPI 卡片。
3. **PM 卡片墙**：每位 PM 的头像/姓名、负责项目数、风险状态。
4. **项目阶段分布**：各阶段项目数量统计与可视化。
5. **风险项目清单**：高/中风险项目详情、原因、应对措施、负责人。
6. **项目详情表**：项目名称、阶段、PM、风险等级、本周进展、下周计划。
7. **回款跟踪**：项目回款进度汇总。
8. **下周重点**：关键里程碑和重点事项。

## 强制工作流

每次生成周报必须按以下顺序执行：

1. **内容结构化**
   - 读取 `references/content-model.md`。
   - 从原始素材中提取：报告周期、项目列表、PM、阶段、风险、进展、回款等。
   - 将原始数据转换为结构化报告模型，再生成 HTML。
   - 禁止编造日期、负责人、百分比、金额或完成率。

2. **报告结构选择**
   - 读取 `references/report-structures.md`。
   - 优先选择项目组合周报结构（project portfolio variant）。
   - 根据素材完整性决定保留或删除哪些模块。

3. **UI Ux Pro Max 设计通过**
   - 读取 `references/ui-ux-pro-max-integration.md`。
   - 默认产品方向：B2B Service + Analytics Dashboard + Executive Dashboard。
   - 甄云品牌色：深蓝主色调。

4. **HTML 生成**
   - 读取 `references/template-selection.md` 选择合适的模板。
   - 优先使用 `weekly-project-milestone.html` 风格的项目周报模板。
   - 使用 `assets/templates/` 中的模板作为起点。
   - 替换所有占位符，添加甄云特化模块（PM 卡片、阶段分布图等）。
   - 交付前检查并清除所有模板标记（`{{...}}`、`填写`、`YYYY` 等）。

5. **PNG 导出**
   - 读取 `references/png-export.md`。
   - 生成 HTML 后立即运行 `scripts/html_to_png.py`。
   - 无需用户手动打开浏览器。

6. **验证**
   - 执行 `references/html-output-checklist.md` 中的检查清单。
   - 确认 HTML 和 PNG 文件均存在且非空。

## 视觉质量标准

生成的周报必须看起来像一份完成的商业产物，而非原始文档：

- 醒目的报告头部，含标题、周期、副标题和元数据。
- 3-6 张 KPI 卡片汇总核心事实。
- PM 卡片墙，展示每位 PM 负责项目和风险状态。
- 项目阶段分布可视化（横向阶段条 + 各阶段项目数）。
- 结构化的项目详情表、风险清单、回款跟踪。
- 状态标签（色彩 + 文字双重编码）。
- 进度条、里程碑时间线等紧凑可视化元素。

## 内容规则

- 结论优先，先总后分，面向管理层。
- 保留原始素材中的事实数据，不编造任何数字。
- 缺失指标显示为 `--` 或直接省略。
- 将模糊描述转化为清晰的业务表述。
- 清晰区分：已完成、进行中、风险、阻塞、决策事项、待支持事项、下周计划。

## HTML 设计规则

应用甄云品牌视觉体系：

- 专业 B2B/分析仪表盘调色板：深蓝头部、浅蓝灰页面背景、白色卡片、蓝色进行中、绿色已完成、琥珀色需关注、红色高风险。
- 使用 KPI 卡片、状态标签、时间线行、进度条、表格、CSS 图表块和重点标注。
- 卡片圆角 8px，避免卡片嵌套。
- 保持高对比度、16px 基本字号、舒适行高、稳定间距。
- 避免大型营销横幅、暗色模糊背景、装饰性元素、emoji 图标。
- 打印输出干净：隐藏阴影、保留表格、避免不当分页。

## 参考文件

按需加载：

- `references/content-model.md`：原始素材结构化方法。
- `references/report-structures.md`：不同报告类型的章节和内容逻辑。
- `references/ui-ux-pro-max-integration.md`：UI Ux Pro Max 设计方法应用。
- `references/template-selection.md`：模板选择规则。
- `references/design-style-guide.md`：最终报告 HTML 设计系统和组件。
- `references/png-export.md`：HTML 转 PNG 导出工作流。
- `references/html-output-checklist.md`：交付前验证检查清单。

## 甄云项目特有约定

- 项目名称使用正式的项目编号或客户名称，如"曼秀雷敦 SRM"、"箭牌家居非商"。
- PM 姓名使用中文全名。
- 风险等级分三级：高风险（红色）、中风险（琥珀色）、低风险（绿色）。
- 回款进度以百分比 + 进度条展示。
- 阶段分布包含：蓝图、开发、测试、上线、验收等阶段。
- 会议纪要为常见源数据格式，需从中提取本周进展和下周计划。
