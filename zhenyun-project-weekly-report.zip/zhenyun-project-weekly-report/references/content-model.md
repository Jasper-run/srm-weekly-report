# Content Model

Before generating HTML, convert raw notes, tables, meeting minutes, or files into this structured report model. Do this mentally or in a short working outline; do not expose the full model unless the user asks.

## Shared Fields

- report_type: daily, weekly, monthly, project, operations, sales, R&D, management summary
- title: final report title
- period: date, week range, or month
- audience: leadership, customer, project team, internal department, or unknown
- organization_or_project: project/team/company name
- owner: report author or responsible team
- overall_status: on track, attention, at risk, blocked, completed, unknown
- current_phase: active project/business stage if available
- overall_progress: percentage or milestone ratio only if source data supports it

## Executive Summary Model

Extract 3-5 conclusion-first points:

- point_title: short business conclusion
- evidence: specific fact from the source
- impact: why it matters
- status: completed, active, attention, risk, or planned

Rules:

- Prefer outcomes over activity descriptions.
- Combine duplicate items.
- Keep each point short enough for a summary card.
- If the source only contains activity, rewrite it as progress plus output.

## KPI Model

Create 3-6 KPI cards only from available facts.

Common weekly KPI candidates:

- completed milestones/items
- in-progress items
- pending items
- overall progress
- risks/blockers
- next-week key deliverables

Common monthly KPI candidates:

- target achievement
- completed initiatives
- core business metric
- month-over-month change
- risks/issues
- next-month priorities

Each KPI needs:

- label
- value
- note/context
- semantic color: green, blue, amber, red, or neutral

Do not create a KPI if there is no value or meaningful status.

## Workstream / Milestone Model

Use for project weekly reports and monthly progress reports.

Fields:

- workstream_or_phase
- item_name
- owner
- planned_date
- actual_date
- progress
- status
- evidence_or_output
- next_action

Status vocabulary:

- 已完成 / Completed
- 进行中 / In Progress
- 待处理 / Pending
- 计划中 / Planned
- 需关注 / Attention
- 有风险 / At Risk
- 阻塞 / Blocked

## Risk And Decision Model

Fields:

- issue_or_risk
- severity: high, medium, low
- impact
- cause if available
- mitigation
- owner
- due_date
- support_needed

Rules:

- Separate confirmed risks from ordinary next steps.
- Do not exaggerate severity.
- If a decision is needed, place it before general risk details in management-facing reports.

## Next Actions Model

Fields:

- priority_order
- action
- owner
- expected_output
- due_date
- dependency

Rules:

- Use concrete verbs.
- For weekly reports, focus on next week.
- For monthly reports, focus on next month priorities and milestones.
