# Design Style Guide

This guide distills the report-relevant parts of UI Ux Pro Max into a focused style system for daily, weekly, and monthly HTML reports.

## Default Style: Executive Project Report

Use this when the user does not specify a style. It is based on B2B Service, Analytics Dashboard, Executive Dashboard, KPI cards, progress indicators, and status tables.

Design qualities:

- Finished management-report feel, not a plain document.
- Dark navy header for authority and first-screen impact.
- White content cards on a light blue-gray page background.
- Clear KPI row immediately under the header.
- Section cards with icon badges, strong titles, and dense but readable content.
- Project reports should include milestone timelines and progress/detail tables when data exists.

Recommended tokens:

```css
:root {
  --page-bg: #eef3f8;
  --surface: #ffffff;
  --surface-soft: #f8fafc;
  --ink: #0f172a;
  --muted: #64748b;
  --border: #dbe3ee;
  --navy: #0f172a;
  --navy-2: #17345f;
  --blue: #3b82f6;
  --green: #22c55e;
  --amber: #f59e0b;
  --red: #ef4444;
  --radius: 8px;
  --shadow: 0 10px 30px rgba(15, 23, 42, .08);
}
```

## Required Report Components

Every generated HTML report should include, when content supports it:

- **Header band**: badge, title, subtitle, reporting period, current phase/status, owner/team, and one highlighted status value.
- **KPI cards**: 3-6 cards with label, large value, short description, and optional color class.
- **Executive summary**: numbered insight items or highlighted conclusion cards.
- **Status table**: milestone, owner, plan date, actual date, status, note.
- **Timeline/progress**: for project reports, show stages as a horizontal timeline on desktop and vertical/list layout on mobile.
- **Action list**: next steps with order, owner/date if available, and expected output.
- **Risk list/table**: severity, impact, response, owner, due date.

## Layout Patterns

- Use a centered `.page` container between 1080px and 1180px.
- Use 28-36px page padding on desktop and 16-20px on mobile.
- Header should be visually prominent but not marketing-like: no hero image, no decorative orb, no oversized H1.
- KPI grid should be near the top and responsive: 4 columns desktop, 2 tablet, 1 mobile when narrow.
- Main sections should stack vertically; use two-column layouts only for short side panels.
- For wide tables, wrap them in a scroll container on mobile.

## Component Rules

KPI cards:

- Use 12-13px muted labels, 28-36px values, and tabular numbers.
- Values should use semantic colors only when meaningful: green completed, blue progress, amber attention, red risk.
- Avoid hover-only meaning. Hover lift is optional and should be subtle.

Section titles:

- Use a small 32-40px icon square plus clear title.
- Icons should be inline SVG or CSS symbols, not emoji and not external icon fonts.
- Icon color must match the section purpose.

Summary items:

- Prefer numbered rows with a dark circular number marker.
- Use a soft tinted background and subtle border.
- Each item should have a short title and one concise paragraph.

Timeline:

- Use 3-6 stages maximum in the visual timeline.
- Combine status color with text labels: completed, active, pending, planned, blocked.
- Always provide the same information in a table or detail cards below the visual timeline.

Tables:

- Use subtle header background, comfortable row padding, and clear status chips.
- Align numbers and dates consistently.
- Keep text 13-14px minimum in dense tables.
- Use borders over heavy shadows for hierarchy.

Charts/progress:

- Prefer CSS progress bars, bullet charts, compact bar rows, or inline SVG.
- Always show the exact value as text beside the visual mark.
- Do not add chart libraries unless the user explicitly allows dependencies.

## Alternative Styles

Use only when the user requests a specific tone:

- **Minimal executive**: mostly white, thin borders, fewer cards, more whitespace.
- **Data-dense operations**: tighter cards, more tables, compact progress bars.
- **Government/public service**: highest contrast, conservative navy, explicit labels.
- **Financial dark**: dark surfaces and green/red indicators; use only for screen-first dashboards, not print-first reports.

## Anti-Patterns To Avoid

- Plain white page with only basic bordered sections.
- Large blank areas with weak hierarchy.
- KPI cards with no descriptions or context.
- Gray-on-gray low contrast.
- Decorative gradients, blurred blobs, floating orbs, or stock-image heroes.
- Emoji icons in section titles.
- Tables without status labels or visible values.
- Report pages that look like landing pages rather than work artifacts.

## Accessibility And Print

- Base body text should be 16px with line-height around 1.55.
- Normal text contrast should meet at least WCAG AA.
- Use semantic headings in order.
- Add `@media print` styles: white background, remove shadows, avoid broken cards/tables, keep colors readable.
- Avoid hover-only interactions. Reports should be understandable as static documents.