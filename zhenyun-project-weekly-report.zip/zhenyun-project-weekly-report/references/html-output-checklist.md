# HTML Output Checklist

Before final delivery, check the generated report HTML against this list.

## Process

- Raw material was first converted into a structured report model.
- Report sections were selected from the report type and audience.
- UI Ux Pro Max design pass was applied before HTML generation.
- PNG export was run after HTML generation when producing a weekly/monthly report.
- Missing data was omitted or shown as `--`; no numbers, dates, owners, or rates were invented.
- No template markers or prompt words remain in the final HTML: `{{...}}`, `填写`, `YYYY`, sample customer names, or unsupported example numbers.

## Content

- Report type and period are visible near the top.
- Audience, project, team, or owner is included when known.
- Executive summary or daily summary appears before detailed tables.
- KPI cards reflect available facts and include labels, values, and context.
- Completed work, risks/blockers, decisions/support needed, and next actions are clearly separated.
- Metrics have labels, units, and context where available.

## HTML

- The output is a complete HTML document with `<!doctype html>`, `html`, `head`, and `body`.
- CSS is included in a local `<style>` block unless the user requested otherwise.
- No external CDN is required for the default output.
- The document uses semantic sections and accessible table markup.
- The page title matches the report title.

## Visual Quality

- The page looks like a finished executive/business report, not a plain note document.
- Header, KPI cards, section titles, tables, and status chips share one coherent design system.
- The page is scannable at desktop width and mobile width.
- Text does not overflow buttons, cards, tables, or chips.
- Cards are not nested inside cards unless the inner card is a repeated data item.
- Tables remain readable on small screens, either by responsive wrapping or horizontal containment.
- Colors communicate status together with text labels.
- Progress bar CSS widths are valid percentages and capped at `100%`; values above target are shown in text, not by overflowing the bar.

## Print / Sharing

- Print styles exist.
- Background and shadows do not dominate printed output.
- Important cards, tables, and sections avoid awkward page breaks.
- The HTML file can be opened directly in a browser.
- The PNG file exists, has non-zero size, and visually reflects the report layout.
