# PNG Export

After generating a weekly report HTML file, also generate a matching PNG image. This is part of the default deliverable unless the user explicitly asks for HTML only.

## Tool

Use the bundled script:

```powershell
python "C:\Users\yanzh01\.codex\skills\daily-weekly-monthly-report-html\scripts\html_to_png.py" "<report.html>" --output "<report.png>"
```

The script launches Chrome or Edge in headless mode and captures the rendered page through the Chrome DevTools Protocol. It does not require the user to manually open a browser window and does not require third-party Python packages.

## Defaults

- Output path: same folder and filename as the HTML, with `.png` extension.
- Width: 1440px.
- Maximum capture height: 30000px.
- Extra layout wait: 300ms.

## When To Run

Run this immediately after writing the final HTML file:

1. Generate the structured report HTML.
2. Save it to the user's requested or inferred output folder.
3. Run `scripts/html_to_png.py` against that HTML file.
4. Confirm that the PNG file exists and has non-zero size.
5. Report both output paths to the user.

## Options

Use a wider image for detailed reports:

```powershell
python "C:\Users\yanzh01\.codex\skills\daily-weekly-monthly-report-html\scripts\html_to_png.py" "<report.html>" --width 1600
```

Use a higher max height for long monthly reports:

```powershell
python "C:\Users\yanzh01\.codex\skills\daily-weekly-monthly-report-html\scripts\html_to_png.py" "<report.html>" --max-height 50000
```

Use a writable temporary profile directory when the current environment blocks the browser profile:

```powershell
python "C:\Users\yanzh01\.codex\skills\daily-weekly-monthly-report-html\scripts\html_to_png.py" "<report.html>" --temp-dir "C:\tmp"
```

Specify the browser executable if auto-detection fails:

```powershell
python "C:\Users\yanzh01\.codex\skills\daily-weekly-monthly-report-html\scripts\html_to_png.py" "<report.html>" --browser "C:\Program Files\Google\Chrome\Application\chrome.exe"
```

## Failure Handling

If PNG export fails:

- Do not silently skip the PNG.
- Tell the user the HTML was generated but PNG export failed.
- Include the reason from the script output.
- If the error says `Target crashed`, `Timed out waiting for Chrome DevTools port`, or `Timed out waiting for browser page target`, first treat it as a browser environment or permission issue.
- Retry with permission to launch the browser outside the sandbox when available.
- Retry with `--temp-dir "C:\tmp"` if the default temporary/profile location may be blocked.
- Retry with `--browser "<Chrome or Edge executable>"` if auto-detection picked a bad browser.
- If Chrome/Edge is missing, ask the user to install Chrome/Edge or provide the executable path.
