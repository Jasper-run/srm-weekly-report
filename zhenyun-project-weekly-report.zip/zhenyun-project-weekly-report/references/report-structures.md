# Report Structures

Use these structures as defaults. Adapt section names to the user's industry and source material.

## Daily Report

Best for same-day execution tracking and next-day planning.

Recommended sections:

1. Header: report title, date, team/project, author if known.
2. Today Summary: 2-4 sentence overview of the day's result.
3. Key Metrics: completed items, progress, incidents, pending items, or business indicators.
4. Completed Today: bullet list or table with task, output, owner, status.
5. In Progress: work not yet closed, with current state and expected next step.
6. Issues / Blockers: issue, impact, owner, support needed.
7. Tomorrow Plan: prioritized actions for the next workday.

## Weekly Report

Best for project status, team progress, and management review.

Recommended sections:

1. Header: report title, week range, team/project, report owner.
2. Executive Summary: conclusion first, including overall status.
3. KPI Snapshot: 3-6 core metrics such as completion, milestone progress, delivery count, risks, conversion, cost, quality, or customer feedback.
4. Key Achievements: completed outcomes, not just activity.
5. Progress By Workstream: table grouped by project, module, client, product area, or department.
6. Risks And Blockers: severity, impact, mitigation, owner, due date.
7. Decisions / Support Needed: items requiring leadership or cross-team action.
8. Next Week Plan: focused priorities and milestones.

## Monthly Report

Best for management summaries, business reviews, operational reviews, and customer-facing progress reports.

Recommended sections:

1. Header: month, organization/project, prepared for/by.
2. Month In Brief: 3-5 bullets covering results, progress, deviations, and priorities.
3. Goal Achievement: target vs actual, status, explanation.
4. Core Metrics: KPI cards and trend/comparison table.
5. Major Work Completed: grouped by initiative, department, or milestone.
6. Business / Project Analysis: what changed, why it matters, and evidence.
7. Problems And Root Causes: distinguish symptoms, causes, impact, and actions.
8. Risk Register: status, severity, response plan, owner.
9. Next Month Priorities: 3-6 concrete priorities with expected outputs.
10. Appendix: detailed tables if necessary.

## Management-Facing Variant

Use when the report is for leaders, executives, customers, or steering committees.

- Put conclusions and decisions before process details.
- Use status labels: On Track, Attention, At Risk, Blocked.
- Include only the details needed to support decisions.
- Add a clear section for support needed, decision items, and next checkpoints.

## Project Variant

Use when the report tracks delivery.

- Show milestones and workstreams.
- Separate scope, schedule, quality, cost, and risk when information is available.
- Use a table for progress by module/workstream.
- Make blockers explicit with owner and expected resolution date.

## Operations / Sales Variant

Use when the report contains business metrics.

- Compare current period with target, previous period, or same period last year when data exists.
- Explain outliers and major changes.
- Use tables for ranking, pipeline, conversion, revenue, cases, tickets, or campaign data.
- Never invent baseline numbers.
