# Template Selection

Use this reference after the content model is built and before generating HTML.

## Default Templates

- `daily-report.html`: daily execution report.
- `weekly-report.html`: default polished weekly report.
- `monthly-report.html`: default polished monthly report.

## Specialized Templates

### `weekly-executive-brief.html`

Use for leadership-facing weekly reports where the reader needs decisions, risks, and next actions before details.

Best fit:

- 管理层周报
- 领导汇报
- steering committee update
- customer-facing project brief
- reports with support-needed or decision-needed content

Content emphasis:

- conclusion-first summary
- decision items
- risk/support table
- 4 KPI cards maximum
- short action-oriented copy

### `weekly-project-milestone.html`

Use for project delivery weekly reports where progress, milestones, phase gates, and blockers are the core story.

Best fit:

- 项目周报
- 交付周报
- 系统建设周报
- implementation and rollout tracking
- reports with stage dates, milestone status, or workstream progress

Content emphasis:

- dark project header
- milestone stages
- workflow progress bars
- milestone detail table
- risk/blocker visibility

### `monthly-operations-dashboard.html`

Use for operations monthly reports where metrics, target achievement, issue classification, and management recommendations matter most.

Best fit:

- 运营月报
- 客服月报
- 系统运营月报
- process efficiency report
- service quality or issue closure report

Content emphasis:

- metric dashboard
- compact trend blocks
- target achievement bars
- issue category table
- management recommendations

### `monthly-sales-business-review.html`

Use for business or sales monthly reports where revenue, pipeline, customers, region, and commercial conversion matter most.

Best fit:

- 经营月报
- 销售月报
- 区域月报
- pipeline review
- customer and revenue review

Content emphasis:

- business review header
- pipeline stage cards
- target achievement by region/team
- key customer table
- revenue and conversion KPIs

## Selection Rules

1. If the user explicitly names a template or report type, use that template.
2. If the audience is leadership and the report asks for decisions/support, prefer `weekly-executive-brief.html`.
3. If the report contains project stages, milestones, planned dates, actual dates, or rollout phases, prefer `weekly-project-milestone.html`.
4. If the report contains many operational metrics, issue categories, closure rates, or service/process indicators, prefer `monthly-operations-dashboard.html`.
5. If the report contains revenue, sales targets, pipeline stages, opportunities, customers, regions, or collection/payment metrics, prefer `monthly-sales-business-review.html`.
6. If none of the above is clear, use `weekly-report.html` or `monthly-report.html` as the default.

## Adaptation Rules

- Remove sections that are not supported by the source material.
- Do not invent metrics just to fill a visual component.
- Keep the template's visual language, but adapt titles, KPI labels, tables, and section order to the content model.
- Treat `{{placeholder}}` tokens in templates as replacement markers, not final content.
- Replace every `{{...}}` token with source-supported content, `--` for explicitly missing simple values, or remove the unsupported section.
- Do not leave sample dates, customer names, amounts, percentages, or prompt words such as `填写` in the final HTML.
- For progress bars above 100%, cap CSS bar width at `100%` and show the real value as text beside the bar.
- After generating the HTML, export PNG with `scripts/html_to_png.py`.
