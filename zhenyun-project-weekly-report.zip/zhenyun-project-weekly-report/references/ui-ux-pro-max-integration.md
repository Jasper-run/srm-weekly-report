# UI Ux Pro Max Integration

This skill must apply UI Ux Pro Max as a design-system pass after content is structured and before HTML is generated.

## Integration Principle

Do not start from decoration. Start from the structured report model, then use UI Ux Pro Max methods to choose the right product type, style, color tokens, components, chart patterns, accessibility rules, and responsive behavior.

## If UI Ux Pro Max Is Available Locally

When deeper design guidance is needed, query the existing UI Ux Pro Max skill data instead of guessing. Typical path on this machine:

`C:\Users\yanzh01\.codex\skills\ui-ux-pro-max\scripts\search.py`

Useful searches:

```powershell
python "C:\Users\yanzh01\.codex\skills\ui-ux-pro-max\scripts\search.py" "B2B Service analytics dashboard executive report" --domain color --max-results 3
python "C:\Users\yanzh01\.codex\skills\ui-ux-pro-max\scripts\search.py" "executive dashboard KPI cards progress table timeline" --domain style --max-results 4
python "C:\Users\yanzh01\.codex\skills\ui-ux-pro-max\scripts\search.py" "KPI progress target status report" --domain chart --max-results 4
python "C:\Users\yanzh01\.codex\skills\ui-ux-pro-max\scripts\search.py" "responsive report dashboard accessibility table contrast" --domain ux --max-results 4
```

Use the results as design input. Do not paste raw search results into the final report unless the user asks.

## Default UI Ux Pro Max Mapping

For weekly/monthly reports, use this default mapping unless the user's domain clearly suggests another choice:

- Product type: B2B Service + Analytics Dashboard
- Style: Executive Dashboard + Data-Dense Dashboard
- Color direction: professional navy, white cards, blue data highlights, green completed, amber attention, red risk
- Chart patterns: KPI cards, bullet/progress bars, status tables, timeline, compact bar rows
- UX priorities: accessibility, layout/responsive, typography/color, charts/data, print quality

## Design Selection Rules

Choose by report content:

- Project weekly report: Executive Project Report, milestone timeline, phase cards, status table, risk table.
- Management weekly report: Executive Dashboard, top KPI row, numbered conclusions, decisions/support needed before details.
- Operations monthly report: Data-Dense Dashboard, KPI cards, comparison tables, progress/bullet charts, issue analysis.
- Sales monthly report: Sales Intelligence Dashboard, pipeline/funnel table, target achievement, ranking table, risk/opportunity list.
- Financial monthly report: Financial Dashboard style, target vs actual, variance colors, audit/detail table; avoid dark mode if print-first.

## Component Translation

After choosing the design direction, translate the content model into UI components:

- executive_summary -> numbered summary cards
- kpis -> KPI card grid
- milestones -> timeline + milestone table
- workstreams -> progress table or grouped workstream cards
- targets -> bullet/progress bars with visible values
- risks -> risk table with severity chips
- next_actions -> ordered action list
- decisions/support_needed -> highlighted callout near the top

## Visual Effects Allowed

Use restrained effects inspired by UI Ux Pro Max:

- dark navy gradient header for executive presence
- soft card shadows for hierarchy
- subtle hover lift only for screen viewing
- tinted icon badges for section recognition
- progress bars and status chips for scannability
- light blue-gray page background to separate the report canvas

Avoid:

- decorative gradient blobs or orbs
- stock images or hero imagery
- glassmorphism unless explicitly requested
- animated effects that distract from report reading
- low contrast pastel-only palettes
- emoji icons

## Output Decision Record

Before writing HTML, decide these internally:

- selected product type
- selected style category
- color tokens
- component set
- chart/progress patterns
- omitted sections and why

Use this decision record to keep the report visually coherent.
