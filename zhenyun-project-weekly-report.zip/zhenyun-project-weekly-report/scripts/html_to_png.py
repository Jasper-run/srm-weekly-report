#!/usr/bin/env python3
"""Convert a local HTML report to a PNG image using headless Chrome/Edge.

No third-party Python packages are required. The script launches a headless
browser process, talks to Chrome DevTools Protocol directly, measures the page,
and captures a PNG without opening a visible browser window.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from pathlib import Path


DEFAULT_WIDTH = 1440
DEFAULT_MAX_HEIGHT = 30000


class HtmlToPngError(RuntimeError):
    pass


def find_browser(explicit: str | None = None) -> str:
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)
    env_path = os.environ.get("CHROME_PATH") or os.environ.get("BROWSER_PATH")
    if env_path:
        candidates.append(env_path)

    if os.name == "nt":
        candidates.extend([
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        ])
        path_names = ["chrome.exe", "msedge.exe", "chromium.exe"]
    elif sys.platform == "darwin":
        candidates.extend([
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ])
        path_names = ["google-chrome", "chrome", "chromium", "microsoft-edge"]
    else:
        path_names = ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "microsoft-edge-stable"]

    for name in path_names:
        found = shutil.which(name)
        if found:
            candidates.append(found)

    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))

    raise HtmlToPngError(
        "No Chrome/Edge executable found. Install Chrome/Edge or pass --browser /path/to/browser."
    )


def to_url(source: str) -> str:
    if source.startswith(("http://", "https://", "file://")):
        return source
    path = Path(source).expanduser().resolve()
    if not path.exists():
        raise HtmlToPngError(f"HTML file not found: {path}")
    return path.as_uri()


def http_json(url: str, timeout: float = 2.0):
    with urllib.request.urlopen(url, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def wait_for_debug_port(profile_dir: Path, timeout: float = 10.0) -> int:
    port_file = profile_dir / "DevToolsActivePort"
    deadline = time.time() + timeout
    while time.time() < deadline:
        if port_file.exists():
            lines = port_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            if lines and lines[0].strip().isdigit():
                return int(lines[0].strip())
        time.sleep(0.05)
    raise HtmlToPngError("Timed out waiting for Chrome DevTools port.")


def wait_for_page(port: int, timeout: float = 10.0) -> dict:
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            targets = http_json(f"http://127.0.0.1:{port}/json/list")
            pages = [target for target in targets if target.get("type") == "page" and target.get("webSocketDebuggerUrl")]
            if pages:
                return pages[0]
        except Exception as exc:  # pragma: no cover - diagnostic path
            last = exc
        time.sleep(0.1)
    raise HtmlToPngError(f"Timed out waiting for browser page target. Last error: {last}")


def collect_browser_diagnostics(
    process: subprocess.Popen | None,
    stdout_path: Path | None = None,
    stderr_path: Path | None = None,
    limit: int = 4000,
) -> str:
    if not process:
        return ""

    parts: list[str] = []
    if process.poll() is None:
        parts.append("browser process was still running when the error occurred")
        process.terminate()
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                parts.append("browser process did not exit after kill")
    if process.poll() is None:
        return "\n".join(parts)

    if not any(part.startswith("browser exit code:") for part in parts):
        parts.append(f"browser exit code: {process.returncode}")

    stdout = ""
    stderr = ""
    if stdout_path and stdout_path.exists():
        stdout = stdout_path.read_text(encoding="utf-8", errors="replace")
    if stderr_path and stderr_path.exists():
        stderr = stderr_path.read_text(encoding="utf-8", errors="replace")
    if not stdout_path and not stderr_path:
        try:
            stdout_bytes, stderr_bytes = process.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            parts.append("timed out while reading browser diagnostics")
            process.kill()
            try:
                stdout_bytes, stderr_bytes = process.communicate(timeout=1)
            except subprocess.TimeoutExpired:
                stdout_bytes, stderr_bytes = b"", b""
        stdout = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
        stderr = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""

    if stdout.strip():
        parts.append("stdout:\n" + stdout.strip()[-limit:])
    if stderr.strip():
        parts.append("stderr:\n" + stderr.strip()[-limit:])
    return "\n".join(parts)


def troubleshooting_hint(message: str) -> str:
    lower = message.lower()
    if (
        "target crashed" in lower
        or "devtools port" in lower
        or "page target" in lower
        or "temporary directory" in lower
        or "browser profile directory" in lower
    ):
        return (
            "Hint: headless Chrome/Edge may be unable to create or access its temporary profile in the current sandbox. "
            "Retry with permission to launch the browser outside the sandbox, pass --browser to a known Chrome/Edge path, "
            "or pass --temp-dir to a writable directory such as C:\\tmp."
        )
    return ""


def make_profile_dir(temp_parent: Path | None) -> Path:
    base = temp_parent or Path(tempfile.gettempdir()).resolve()
    try:
        base.mkdir(parents=True, exist_ok=True)
    except PermissionError as exc:
        raise HtmlToPngError(f"Cannot access temporary directory for browser profile: {base}") from exc

    stamp = int(time.time() * 1000)
    for index in range(50):
        candidate = base / f"report-html-to-png-{os.getpid()}-{stamp}-{index}"
        try:
            candidate.mkdir(mode=0o700)
            return candidate
        except FileExistsError:
            continue
        except PermissionError as exc:
            raise HtmlToPngError(f"Cannot create browser profile directory under {base}: {exc}") from exc
    raise HtmlToPngError(f"Could not create a unique browser profile directory under {base}.")


class DevToolsSocket:
    def __init__(self, ws_url: str):
        parsed = urllib.parse.urlparse(ws_url)
        if parsed.scheme != "ws":
            raise HtmlToPngError(f"Unsupported DevTools URL: {ws_url}")
        self.host = parsed.hostname or "127.0.0.1"
        self.port = parsed.port or 80
        self.path = parsed.path
        if parsed.query:
            self.path += "?" + parsed.query
        self.sock = socket.create_connection((self.host, self.port), timeout=5)
        self.sock.settimeout(30)
        self._next_id = 1
        self._handshake()

    def _handshake(self) -> None:
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET {self.path} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(request.encode("ascii"))
        response = b""
        while b"\r\n\r\n" not in response:
            chunk = self.sock.recv(4096)
            if not chunk:
                break
            response += chunk
        if b" 101 " not in response.split(b"\r\n", 1)[0]:
            raise HtmlToPngError("Chrome DevTools WebSocket handshake failed.")

    def close(self) -> None:
        try:
            self.sock.close()
        except Exception:
            pass

    def _send_frame(self, payload: str) -> None:
        data = payload.encode("utf-8")
        header = bytearray([0x81])
        length = len(data)
        if length < 126:
            header.append(0x80 | length)
        elif length < (1 << 16):
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        mask = os.urandom(4)
        header.extend(mask)
        masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(data))
        self.sock.sendall(bytes(header) + masked)

    def _read_exact(self, size: int) -> bytes:
        chunks = bytearray()
        while len(chunks) < size:
            chunk = self.sock.recv(size - len(chunks))
            if not chunk:
                raise HtmlToPngError("DevTools WebSocket closed unexpectedly.")
            chunks.extend(chunk)
        return bytes(chunks)

    def _recv_frame(self) -> str | None:
        first = self._read_exact(2)
        opcode = first[0] & 0x0F
        masked = bool(first[1] & 0x80)
        length = first[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", self._read_exact(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", self._read_exact(8))[0]
        mask = self._read_exact(4) if masked else b""
        payload = self._read_exact(length) if length else b""
        if masked:
            payload = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
        if opcode == 8:
            raise HtmlToPngError("DevTools WebSocket closed.")
        if opcode == 9:
            return None
        if opcode != 1:
            return None
        return payload.decode("utf-8")

    def command(self, method: str, params: dict | None = None, timeout: float = 30.0) -> dict:
        command_id = self._next_id
        self._next_id += 1
        self._send_frame(json.dumps({"id": command_id, "method": method, "params": params or {}}))
        deadline = time.time() + timeout
        while time.time() < deadline:
            message_text = self._recv_frame()
            if not message_text:
                continue
            message = json.loads(message_text)
            if message.get("id") == command_id:
                if "error" in message:
                    raise HtmlToPngError(f"CDP {method} failed: {message['error']}")
                return message.get("result", {})
        raise HtmlToPngError(f"Timed out waiting for CDP response: {method}")


def wait_for_ready(cdp: DevToolsSocket, timeout: float = 15.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        result = cdp.command(
            "Runtime.evaluate",
            {"expression": "document.readyState", "returnByValue": True},
            timeout=5,
        )
        state = result.get("result", {}).get("value")
        if state == "complete":
            return
        time.sleep(0.1)


def evaluate_number(cdp: DevToolsSocket, expression: str) -> int:
    result = cdp.command(
        "Runtime.evaluate",
        {"expression": expression, "returnByValue": True},
        timeout=10,
    )
    value = result.get("result", {}).get("value")
    try:
        return int(value)
    except Exception as exc:
        raise HtmlToPngError(f"Expected numeric Runtime.evaluate result, got {value!r}") from exc


def convert_html_to_png(
    source: str,
    output: str | None,
    width: int,
    max_height: int,
    browser_path: str | None,
    wait_ms: int,
    temp_dir: str | None,
) -> Path:
    url = to_url(source)
    source_path = Path(source).expanduser()
    if output:
        output_path = Path(output).expanduser().resolve()
    elif source_path.suffix:
        output_path = source_path.with_suffix(".png").resolve()
    else:
        output_path = Path("report.png").resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    browser = find_browser(browser_path)
    temp_parent = Path(temp_dir).expanduser().resolve() if temp_dir else None
    profile = make_profile_dir(temp_parent)
    process = None
    cdp = None
    stdout_log = None
    stderr_log = None
    stdout_handle = None
    stderr_handle = None
    try:
        args = [
            browser,
            "--headless=new",
            "--disable-gpu",
            "--hide-scrollbars",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-networking",
            "--disable-breakpad",
            "--disable-crash-reporter",
            "--disable-extensions",
            "--disable-sync",
            "--run-all-compositor-stages-before-draw",
            "--remote-debugging-port=0",
            f"--user-data-dir={profile}",
            f"--window-size={width},900",
            url,
        ]
        stdout_log = profile / "browser-stdout.log"
        stderr_log = profile / "browser-stderr.log"
        stdout_handle = stdout_log.open("wb")
        stderr_handle = stderr_log.open("wb")
        process = subprocess.Popen(args, stdout=stdout_handle, stderr=stderr_handle)
        stdout_handle.close()
        stderr_handle.close()
        stdout_handle = None
        stderr_handle = None
        port = wait_for_debug_port(profile)
        page = wait_for_page(port)
        cdp = DevToolsSocket(page["webSocketDebuggerUrl"])
        cdp.command("Page.enable")
        cdp.command("Runtime.enable")
        wait_for_ready(cdp)
        if wait_ms > 0:
            time.sleep(wait_ms / 1000)
        height_expr = "Math.ceil(Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight))"
        page_height = max(1, evaluate_number(cdp, height_expr))
        capture_height = min(page_height, max_height)
        cdp.command(
            "Emulation.setDeviceMetricsOverride",
            {
                "width": width,
                "height": capture_height,
                "deviceScaleFactor": 1,
                "mobile": False,
            },
        )
        cdp.command("Runtime.evaluate", {"expression": "window.scrollTo(0, 0)", "returnByValue": True})
        screenshot = cdp.command(
            "Page.captureScreenshot",
            {
                "format": "png",
                "fromSurface": True,
                "captureBeyondViewport": True,
                "clip": {"x": 0, "y": 0, "width": width, "height": capture_height, "scale": 1},
            },
            timeout=60,
        )
        data = screenshot.get("data")
        if not data:
            raise HtmlToPngError("Chrome returned an empty screenshot.")
        output_path.write_bytes(base64.b64decode(data))
        if page_height > max_height:
            print(
                f"Warning: page height {page_height}px exceeded --max-height {max_height}px; PNG was clipped.",
                file=sys.stderr,
            )
        return output_path
    except HtmlToPngError as exc:
        diagnostics = collect_browser_diagnostics(process, stdout_log, stderr_log)
        hint = troubleshooting_hint(str(exc))
        details = [str(exc)]
        if diagnostics:
            details.append("Browser diagnostics:\n" + diagnostics)
        if hint:
            details.append(hint)
        raise HtmlToPngError("\n".join(details)) from exc
    finally:
        if cdp:
            cdp.close()
        if stdout_handle:
            stdout_handle.close()
        if stderr_handle:
            stderr_handle.close()
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
        shutil.rmtree(profile, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Convert a local HTML report into a PNG image without opening a visible browser.")
    parser.add_argument("html", help="Input HTML file path or URL")
    parser.add_argument("--output", "-o", help="Output PNG path. Defaults to input filename with .png")
    parser.add_argument("--width", type=int, default=DEFAULT_WIDTH, help=f"Viewport/capture width in px. Default: {DEFAULT_WIDTH}")
    parser.add_argument("--max-height", type=int, default=DEFAULT_MAX_HEIGHT, help=f"Maximum capture height in px. Default: {DEFAULT_MAX_HEIGHT}")
    parser.add_argument("--browser", help="Path to Chrome/Edge executable. Optional when installed in a common location.")
    parser.add_argument("--wait-ms", type=int, default=300, help="Extra wait time before capture for fonts/layout. Default: 300")
    parser.add_argument("--temp-dir", help="Directory for the temporary browser profile. Useful when the default temp/profile location is blocked.")
    args = parser.parse_args(argv)

    try:
        png = convert_html_to_png(args.html, args.output, args.width, args.max_height, args.browser, args.wait_ms, args.temp_dir)
    except HtmlToPngError as exc:
        message = str(exc)
        hint = troubleshooting_hint(message)
        if hint and hint not in message:
            message = message + "\n" + hint
        print(f"html_to_png error: {message}", file=sys.stderr)
        return 1
    print(str(png))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
